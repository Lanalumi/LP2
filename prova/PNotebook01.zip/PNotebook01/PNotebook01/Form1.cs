﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotebook01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            double[,] Preco = new double[3,3];
            double[] Medias = new double[3];
            double preco;
            string entrada = "";
          
            for (int i = 0; i < 3; i++)
            {

                for (int j = 0; j < 3; j++) 
                {
                    entrada = Interaction.InputBox($"Digite o preço do notebook {i+1} da loja{j+1}");
                    
                    if (!double.TryParse(entrada, out preco) && preco >= 0)
                    {
                        MessageBox.Show("O preço deve ser maior ou igual a 0");
                        j--;
                    }
                    else
                    {
                        Preco[i,j] = preco;
                        lstResultado.Items.Add($"Notebook {i + 1}: Loja{j + 1}{Preco[i, j].ToString("C2")}");

                    }
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstResultado.Items.Clear();
        }
    }
}

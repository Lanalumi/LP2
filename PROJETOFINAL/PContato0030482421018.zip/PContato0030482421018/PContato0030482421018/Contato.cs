﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PContato0030482421018
{
    public class Contato
    {

        public int ID_CONTATO { get; set; }
        public string NOME_CONTATO { get; set; }
        public string END_CONTATO { get; set; }
        public int CIDADE_ID_CIDADE { get; set; }
        public string CEL_CONTATO { get; set; }
        public string EMAIL_CONTATO { get; set; }
        public DateTime DTCADASTRO_CONTATO { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daContato;
            DataTable dtContato = new DataTable();

            try
            {
                daContato = new SqlDataAdapter("SELECT * FROM CONTATO", frmPrincipal.conexao);
                daContato.Fill(dtContato);
                daContato.FillSchema(dtContato, SchemaType.Source);
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return dtContato;

        }
        public int Incluir()
        {
            int retorno = 0;
            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("INSERT INTO CONTATO(NOME_CONTATO, END_CONTATO, CIDADE_ID_CIDADE, CEL_CONTATO, EMAIL_CONTATO, DTCADASTRO_CONTATO) VALUES (@nome_contato," +
                    "@end_contato, @cidade_id_cidade," +
                    "@cel_contato, @email_contato, @dtcadastro_contato)", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@nome_contato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@end_contato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@cidade_id_cidade", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@cel_contato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@email_contato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastro_contato", SqlDbType.Date));

                mycommand.Parameters["@nome_contato"].Value = NOME_CONTATO;
                mycommand.Parameters["@end_contato"].Value = END_CONTATO;
                mycommand.Parameters["@cidade_id_cidade"].Value = CIDADE_ID_CIDADE;
                mycommand.Parameters["@cel_contato"].Value = CEL_CONTATO;
                mycommand.Parameters["@email_contato"].Value = EMAIL_CONTATO;
                mycommand.Parameters["@dtcadastro_contato"].Value = DTCADASTRO_CONTATO;


                retorno = mycommand.ExecuteNonQuery();
            }

            catch (Exception)
            {
                throw;
            }
            return retorno;

        }
        public int Excluir()
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;
                mycommand = new SqlCommand("DELETE FROM CONTATO WHERE id_contato=@id_contato", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@id_contato", SqlDbType.Int));
                mycommand.Parameters["@id_contato"].Value = Convert.ToInt16(ID_CONTATO);

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return retorno;
        }

        public int salvar()
        {
            int retorno = 0;
            try
            {
                SqlCommand mycommand;
                mycommand = new SqlCommand("INSERT INTO CONTATO(NOME_CONTATO, END_CONTATO, CIDADE_ID_CIDADE, CEL_CONTATO, EMAIL_CONTATO, DTCADASTRO_CONTATO) VALUES (@nome_contato,@end_contato,@cidade_id_cidade,@cel_contato, @email_contato,@dtcadastro_contato)", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@nome_contato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@end_contato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@cidade_id_cidade", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@cel_contato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@email_contato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastro_contato", SqlDbType.Date));

                mycommand.Parameters["@nome_contato"].Value = NOME_CONTATO;
                mycommand.Parameters["@end_contato"].Value = END_CONTATO;
                mycommand.Parameters["@cidade_id_cidade"].Value = CIDADE_ID_CIDADE;
                mycommand.Parameters["@cel_contato"].Value = CEL_CONTATO;
                mycommand.Parameters["@email_contato"].Value = EMAIL_CONTATO;
                mycommand.Parameters["@dtcadastro_contato"].Value = DTCADASTRO_CONTATO;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception ex )
            {
                 throw ex;
            }
            return retorno;
        }
        public int Alterar()
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;
                mycommand = new SqlCommand("UPDATE CONTATO SET NOME_CONTATO=@nome_contato," +
                    "END_CONTATO=@end_contato," +
                    " CIDADE_ID_CIDADE=@cidade_id_cidade, CEL_CONTATO=@cel_contato," +
                    "EMAIL_CONTATO=@email_contato, " +
                    " DTCADASTRO_CONTATO=@dtcadastro_contato WHERE ID_CONTATO = @id_contato",
                    frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@id_contato", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@nome_contato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@end_contato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@cidade_id_cidade", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@cel_contato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@email_contato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastro_contato", SqlDbType.Date));

                mycommand.Parameters["@id_contato"].Value = ID_CONTATO;
                mycommand.Parameters["@nome_contato"].Value = NOME_CONTATO;
                mycommand.Parameters["@end_contato"].Value = END_CONTATO;
                mycommand.Parameters["@cidade_id_cidade"].Value = CIDADE_ID_CIDADE;
                mycommand.Parameters["@cel_contato"].Value = CEL_CONTATO;
                mycommand.Parameters["@email_contato"].Value = EMAIL_CONTATO;
                mycommand.Parameters["@dtcadastro_contato"].Value = DTCADASTRO_CONTATO;


                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }


    }

}

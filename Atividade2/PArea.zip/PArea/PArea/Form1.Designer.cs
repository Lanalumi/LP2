﻿namespace PArea
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAltRet = new System.Windows.Forms.Label();
            this.lblBaseRet = new System.Windows.Forms.Label();
            this.lblAreaRet = new System.Windows.Forms.Label();
            this.txtbxAltRet = new System.Windows.Forms.TextBox();
            this.txtBaseRet = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtArea = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblAltRet
            // 
            this.lblAltRet.AutoSize = true;
            this.lblAltRet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAltRet.Location = new System.Drawing.Point(22, 26);
            this.lblAltRet.Name = "lblAltRet";
            this.lblAltRet.Size = new System.Drawing.Size(182, 25);
            this.lblAltRet.TabIndex = 0;
            this.lblAltRet.Text = "Altura do retângulo:";
            // 
            // lblBaseRet
            // 
            this.lblBaseRet.AutoSize = true;
            this.lblBaseRet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaseRet.Location = new System.Drawing.Point(22, 76);
            this.lblBaseRet.Name = "lblBaseRet";
            this.lblBaseRet.Size = new System.Drawing.Size(176, 25);
            this.lblBaseRet.TabIndex = 1;
            this.lblBaseRet.Text = "Base do retângulo:";
            this.lblBaseRet.Click += new System.EventHandler(this.lblLargRet_Click);
            // 
            // lblAreaRet
            // 
            this.lblAreaRet.AutoSize = true;
            this.lblAreaRet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAreaRet.Location = new System.Drawing.Point(22, 143);
            this.lblAreaRet.Name = "lblAreaRet";
            this.lblAreaRet.Size = new System.Drawing.Size(174, 25);
            this.lblAreaRet.TabIndex = 2;
            this.lblAreaRet.Text = "Area do Retângulo";
            // 
            // txtbxAltRet
            // 
            this.txtbxAltRet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxAltRet.Location = new System.Drawing.Point(260, 26);
            this.txtbxAltRet.Name = "txtbxAltRet";
            this.txtbxAltRet.Size = new System.Drawing.Size(246, 30);
            this.txtbxAltRet.TabIndex = 3;
            // 
            // txtBaseRet
            // 
            this.txtBaseRet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBaseRet.Location = new System.Drawing.Point(260, 76);
            this.txtBaseRet.Name = "txtBaseRet";
            this.txtBaseRet.Size = new System.Drawing.Size(246, 30);
            this.txtBaseRet.TabIndex = 4;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(145, 249);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(232, 110);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular area";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtArea
            // 
            this.txtArea.Enabled = false;
            this.txtArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArea.Location = new System.Drawing.Point(260, 143);
            this.txtArea.Name = "txtArea";
            this.txtArea.Size = new System.Drawing.Size(246, 30);
            this.txtArea.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtArea);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtBaseRet);
            this.Controls.Add(this.txtbxAltRet);
            this.Controls.Add(this.lblAreaRet);
            this.Controls.Add(this.lblBaseRet);
            this.Controls.Add(this.lblAltRet);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAltRet;
        private System.Windows.Forms.Label lblBaseRet;
        private System.Windows.Forms.Label lblAreaRet;
        private System.Windows.Forms.TextBox txtbxAltRet;
        private System.Windows.Forms.TextBox txtBaseRet;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtArea;
    }
}


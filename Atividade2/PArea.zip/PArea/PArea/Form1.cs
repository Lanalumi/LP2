﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PArea
{
    public partial class Form1 : Form
    {
        double baseRet, altura, area;

        private void lblLargRet_Click(object sender, EventArgs e)
        {

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxAltRet.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura inválida, digite novamente");
                txtbxAltRet.Focus();
            }
            else if (!double.TryParse(txtBaseRet.Text, out baseRet) || (baseRet <= 0))
            {
                MessageBox.Show("Base inválida, digite novamente");
                txtBaseRet.Focus();
            }
            else 
            {
                area = altura * baseRet;
                txtArea.Text = area.ToString();
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PFuncao
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtValX.Text, out double x))
            {
                double y = 3 * x + 2;
                txtValy.Text = y.ToString();
            }
            else
            {
                MessageBox.Show("O valor de X deve ser um número!!");
                txtValX.Focus();
                txtValX.SelectAll();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PExemplo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[] A = { 5,3.4,2,3,4,5,2.5,6.7,5.6,4.6};
            //-------------------------------------------------
            double[] B = new double[10];

            

            for (int i = 0; i < B.Length; i++) 
            {
                if (i % 2 == 0)
                {
                    B[i] = i * 4;
                }
                else
                {
                    B[i] = i + 4;
                }
            }
            lstResultado.Items.Add("Vetor A");
            for (int i = 0; i < A.Length; i++)
            {
                lstResultado.Items.Add(A[i].ToString("N2"));
            
            }
            lstResultado.Items.Add("Vetor B");

            for (int i = 0; i < B.Length; i++)
            {
                lstResultado.Items.Add(B[i].ToString("N2"));

            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstResultado.Items.Clear();
        }
    }
}

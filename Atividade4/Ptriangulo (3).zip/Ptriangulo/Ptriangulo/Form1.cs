﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valA, valB, valC;

        private void txtB_Validated(object sender, EventArgs e)
        {

            if (!Double.TryParse(txtB.Text, out valB))
            {
                MessageBox.Show("Valor de B inválido");
                txtB.Focus();
            }
            else
            {
                if (valB <= 0)
                {
                    MessageBox.Show("Valor de B inválido");
                    txtB.Focus();
                }
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {

            if (!Double.TryParse(txtC.Text, out valC))
            {
                MessageBox.Show("Valor de C inválido");
                txtC.Focus();
            }
            else
            {
                if (valC <= 0)
                {
                    MessageBox.Show("Valor de C inválido");
                    txtC.Focus();
                }
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (valA + valB > valC && Math.Abs(valA - valB) < valC && valB + valC > valA && Math.Abs(valB - valC) < valA && valC + valA > valB && Math.Abs(valC - valA) < valB)
            {
                if (valA == valB && valB == valC)
                {
                    MessageBox.Show("Equilátero");
                }
                else
                {
                    if (valA != valB && valB != valC)
                    {
                        MessageBox.Show("Escaleno");
                    }
                    else
                    {
                        {
                            MessageBox.Show("Isóceles");
                        }
                    }
                }
            }
            else 
            {
                MessageBox.Show("Inválido");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();    
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtA.Text, out valA))
            {
                MessageBox.Show("Valor de A inválido");
                txtA.Focus();
            }
            else
            {
                if (valA <= 0) 
                {
                    MessageBox.Show("Valor de A inválido");
                    txtA.Focus();
                }
            }
        }
    }
}

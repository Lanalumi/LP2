﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica_Lp2_Aula6
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtMatricula_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtProducao_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtSalario_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtGrat_TextChanged(object sender, EventArgs e)
        {
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            string matricula = txtMatricula.Text;
            int producao;
            double salario, grat;

            if (!int.TryParse(txtProducao.Text, out producao) ||
                !double.TryParse(txtSalario.Text, out salario) ||
                !double.TryParse(txtGrat.Text, out grat))
            {
                MessageBox.Show("Produção, Salário e Gratificação devem ser números válidos.");
                return;
            }

            int B = (producao >= 100) ? 1 : 0;
            int C = (producao >= 120) ? 1 : 0;
            int D = (producao >= 150) ? 1 : 0;

            double sb = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + grat;

            if (sb > 7000)
            {
                if (!(producao >= 150 && grat > 0))
                {
                    sb = 7000.00;
                }
            }
            txtSB.Text = sb.ToString("C2");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtMatricula.Clear();
            txtProducao.Clear();
            txtSalario.Clear();
            txtGrat.Clear();
            txtSB.Clear();
        }
    }
}

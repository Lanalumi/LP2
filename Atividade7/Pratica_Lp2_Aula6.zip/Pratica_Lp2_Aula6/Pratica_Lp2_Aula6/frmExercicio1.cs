﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica_Lp2_Aula6
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int qtd = 0;
            for (int i = 0; i < rchtxtTexto.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtTexto.Text[i])) 
                {
                    qtd++;
                }
            }
            MessageBox.Show($"O número de espaços em branco na frase é {qtd}");
        }

        private void btnNumR_Click(object sender, EventArgs e)
        {
            int qtd = 0;
            foreach (char c in rchtxtTexto.Text.ToUpper())
            {
                if (c == 'R')
                {
                    qtd++;
                }
            }
            MessageBox.Show($"O número de R na frase é {qtd}");
        }

        private void btnNumPar_Click(object sender, EventArgs e)
        {
            if (rchtxtTexto.Text.Length > 100)
            {
                MessageBox.Show("Ultrapassou número de caracteres, digite no máximo 100");
            }

            string texto = rchtxtTexto.Text.ToUpper();
            int c = 0;
            char letra1 = '\0';

            foreach(char letra2 in texto) 
            {
                if (letra2 == letra1 && Char.IsLetter(letra2))
                {
                    c++;
                }
                letra1 = letra2;
            }

            MessageBox.Show($"A quantidade de letras repetidas em par: {c}");
        }
    }
}

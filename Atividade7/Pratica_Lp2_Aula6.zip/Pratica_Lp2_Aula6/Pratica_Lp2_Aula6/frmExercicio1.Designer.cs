﻿namespace Pratica_Lp2_Aula6
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtTexto = new System.Windows.Forms.RichTextBox();
            this.btnNumBranco = new System.Windows.Forms.Button();
            this.btnNumR = new System.Windows.Forms.Button();
            this.btnNumPar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtTexto
            // 
            this.rchtxtTexto.Location = new System.Drawing.Point(32, 41);
            this.rchtxtTexto.MaxLength = 100;
            this.rchtxtTexto.Name = "rchtxtTexto";
            this.rchtxtTexto.Size = new System.Drawing.Size(738, 96);
            this.rchtxtTexto.TabIndex = 0;
            this.rchtxtTexto.Text = "";
            // 
            // btnNumBranco
            // 
            this.btnNumBranco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumBranco.Location = new System.Drawing.Point(32, 264);
            this.btnNumBranco.Name = "btnNumBranco";
            this.btnNumBranco.Size = new System.Drawing.Size(149, 92);
            this.btnNumBranco.TabIndex = 1;
            this.btnNumBranco.Text = "Número de espaços em branco";
            this.btnNumBranco.UseVisualStyleBackColor = true;
            this.btnNumBranco.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnNumR
            // 
            this.btnNumR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumR.Location = new System.Drawing.Point(318, 264);
            this.btnNumR.Name = "btnNumR";
            this.btnNumR.Size = new System.Drawing.Size(162, 92);
            this.btnNumR.TabIndex = 2;
            this.btnNumR.Text = "Número de letras R";
            this.btnNumR.UseVisualStyleBackColor = true;
            this.btnNumR.Click += new System.EventHandler(this.btnNumR_Click);
            // 
            // btnNumPar
            // 
            this.btnNumPar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumPar.Location = new System.Drawing.Point(592, 264);
            this.btnNumPar.Name = "btnNumPar";
            this.btnNumPar.Size = new System.Drawing.Size(178, 92);
            this.btnNumPar.TabIndex = 3;
            this.btnNumPar.Text = "Número de ocorrência de par de letras";
            this.btnNumPar.UseVisualStyleBackColor = true;
            this.btnNumPar.Click += new System.EventHandler(this.btnNumPar_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnNumPar);
            this.Controls.Add(this.btnNumR);
            this.Controls.Add(this.btnNumBranco);
            this.Controls.Add(this.rchtxtTexto);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtTexto;
        private System.Windows.Forms.Button btnNumBranco;
        private System.Windows.Forms.Button btnNumR;
        private System.Windows.Forms.Button btnNumPar;
    }
}
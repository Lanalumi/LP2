﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica_Lp2_Aula6
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnNumH_Click(object sender, EventArgs e)
        {
            int N;
            if (!int.TryParse(txtNumN.Text, out N))
            {
                MessageBox.Show("Valor inválido");
                txtNumN.Focus();
            }
            else 
            {
                if (N <= 0)
                {
                    MessageBox.Show("Número não pode ser menor ou igual a 0"); 
                    txtNumN.Focus();
                }
                else
                {
                    double H = 0.0;
                    for (int i = 1; i <= N; i++)
                    {
                        H += 1.0 / i;
                    }
                    MessageBox.Show($"O número H é igual a {H}");

                }
            }

        }

        private void txtNumN_TextChanged(object sender, EventArgs e)
        {
        }
    }
}

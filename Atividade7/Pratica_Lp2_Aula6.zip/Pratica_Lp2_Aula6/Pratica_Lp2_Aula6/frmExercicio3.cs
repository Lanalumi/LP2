﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica_Lp2_Aula6
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            string palavra = txtPalavra1.Text.ToLower();

            palavra = palavra.Replace(" ", "");
            char[] vetor = palavra.ToCharArray();
            Array.Reverse(vetor);
            string invertida = new string(vetor);
            txtInvertida.Text = invertida;

            if (String.Compare(palavra, invertida, true) == 0)
            {
                MessageBox.Show("É um palíndromo!");
            }
            else 
            {
                MessageBox.Show("Não é um palíndromo");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPalavra1.Clear();
            txtInvertida.Clear();
        }
    }
}

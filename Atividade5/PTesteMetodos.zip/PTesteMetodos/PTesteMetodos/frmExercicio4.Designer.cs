﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCaracterBranco = new System.Windows.Forms.Button();
            this.btnContaNum = new System.Windows.Forms.Button();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContaLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCaracterBranco
            // 
            this.btnCaracterBranco.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCaracterBranco.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaracterBranco.Location = new System.Drawing.Point(287, 266);
            this.btnCaracterBranco.Name = "btnCaracterBranco";
            this.btnCaracterBranco.Size = new System.Drawing.Size(180, 94);
            this.btnCaracterBranco.TabIndex = 18;
            this.btnCaracterBranco.Text = "Posição 1º caracter branco";
            this.btnCaracterBranco.UseVisualStyleBackColor = false;
            this.btnCaracterBranco.Click += new System.EventHandler(this.btnCaracterBranco_Click);
            // 
            // btnContaNum
            // 
            this.btnContaNum.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnContaNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaNum.Location = new System.Drawing.Point(66, 266);
            this.btnContaNum.Name = "btnContaNum";
            this.btnContaNum.Size = new System.Drawing.Size(169, 94);
            this.btnContaNum.TabIndex = 17;
            this.btnContaNum.Text = "Conta Números";
            this.btnContaNum.UseVisualStyleBackColor = false;
            this.btnContaNum.Click += new System.EventHandler(this.btnContaNum_Click);
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchtxtFrase.Location = new System.Drawing.Point(124, 52);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(530, 195);
            this.rchtxtFrase.TabIndex = 19;
            this.rchtxtFrase.Text = "";
            // 
            // btnContaLetras
            // 
            this.btnContaLetras.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnContaLetras.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaLetras.Location = new System.Drawing.Point(514, 266);
            this.btnContaLetras.Name = "btnContaLetras";
            this.btnContaLetras.Size = new System.Drawing.Size(204, 94);
            this.btnContaLetras.TabIndex = 20;
            this.btnContaLetras.Text = "Conta Letras";
            this.btnContaLetras.UseVisualStyleBackColor = false;
            this.btnContaLetras.Click += new System.EventHandler(this.btnContaLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContaLetras);
            this.Controls.Add(this.rchtxtFrase);
            this.Controls.Add(this.btnCaracterBranco);
            this.Controls.Add(this.btnContaNum);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCaracterBranco;
        private System.Windows.Forms.Button btnContaNum;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContaLetras;
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pfilme01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            int[] vetor = new int[20];
            string nome = "";
            string nome_2 = "";
            string nome_3 = "";

            nome = Interaction.InputBox("Digite seu nome", "Entrada de Dados");
            nome_2 = Interaction.InputBox("Digite seu nome", "Entrada de Dados");
            nome_3 = Interaction.InputBox("Digite seu nome", "Entrada de Dados");
            ArrayList pessoa = new ArrayList();
            pessoa.Add($"{nome}");
            pessoa.Add($"{nome_2}");
            pessoa.Add($"{nome_3}");
            string lista = string.Join("\n", pessoa.ToArray());
            MessageBox.Show(lista);
            
        }
        
    }
}
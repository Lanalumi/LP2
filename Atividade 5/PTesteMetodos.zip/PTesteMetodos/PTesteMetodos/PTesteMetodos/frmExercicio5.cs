﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int num1; int num2;

            if (!int.TryParse(txtNumero1.Text, out num1) || !int.TryParse(txtNumero2.Text, out num2) || (num2 <= num1))
            {
            MessageBox.Show("Número inválido");
                txtNumero1.Focus();
            }

            else
            {
                Random objs = new Random();
                int x = objs.Next(num1, num2);
                MessageBox.Show(x.ToString());

            }
        }
    }
}
